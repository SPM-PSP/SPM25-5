package com.exam.core.enums;

/**
 * 组卷方式
 */
public interface JoinType {


    /**
     * 题库组题
     */
    Integer REPO_JOIN = 1;
}
