package com.exam.modules.exam.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.exam.entity.ExamDepart;
/**
* <p>
* 考试部门Mapper
* </p>
*
*/
public interface ExamDepartMapper extends BaseMapper<ExamDepart> {

}
