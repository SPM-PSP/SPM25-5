package com.exam.modules.qu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.qu.entity.QuRepo;

/**
* <p>
* 试题题库Mapper
* </p>
*
*/
public interface QuRepoMapper extends BaseMapper<QuRepo> {

}
