package com.exam.modules.user.book.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.user.book.entity.UserBook;

/**
* <p>
* 错题本Mapper
* </p>
*
*/
public interface UserBookMapper extends BaseMapper<UserBook> {

}
