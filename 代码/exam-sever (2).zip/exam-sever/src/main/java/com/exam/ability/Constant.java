package com.exam.ability;


/**
 * 通用常量
 */
public class Constant {


    /**
     * 文件上传路径
     */
    public static final String FILE_PREFIX = "/upload/file/";
}
