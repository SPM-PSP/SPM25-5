package com.exam.modules;


/**
 * 通用常量
 */
public class Constant {

    /**
     * 会话
     */
    public static final String TOKEN = "token";
}
