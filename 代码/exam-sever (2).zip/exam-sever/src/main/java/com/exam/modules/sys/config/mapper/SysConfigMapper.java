package com.exam.modules.sys.config.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.sys.config.entity.SysConfig;

/**
* <p>
* 通用配置Mapper
* </p>
*
*/
public interface SysConfigMapper extends BaseMapper<SysConfig> {

}
