package com.exam.modules.qu.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.qu.entity.QuAnswer;

/**
* <p>
* 候选答案Mapper
* </p>
*
*/
public interface QuAnswerMapper extends BaseMapper<QuAnswer> {

}
