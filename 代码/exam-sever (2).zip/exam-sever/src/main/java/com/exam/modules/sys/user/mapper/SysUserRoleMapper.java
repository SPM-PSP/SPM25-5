package com.exam.modules.sys.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.sys.user.entity.SysUserRole;

/**
* <p>
* 用户角色Mapper
* </p>
*
*/
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

}
