package com.exam.modules.sys.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.sys.user.entity.SysUser;

/**
* <p>
* 管理用户Mapper
* </p>
*
*/
public interface SysUserMapper extends BaseMapper<SysUser> {

}
