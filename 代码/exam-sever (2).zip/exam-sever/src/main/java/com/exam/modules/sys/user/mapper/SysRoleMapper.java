package com.exam.modules.sys.user.mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.sys.user.entity.SysRole;

/**
* <p>
* 角色Mapper
* </p>
*
*/
public interface SysRoleMapper extends BaseMapper<SysRole> {

}
